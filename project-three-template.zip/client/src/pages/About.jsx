import Jumbotron from "../components/Jumbotron";

const About = () => {
  return (
    <div>
      <Jumbotron>
        <h1>ABOUT</h1>
        <p>All about the creators of this project</p>
      </Jumbotron>
    </div>
  );
};

export default About;
